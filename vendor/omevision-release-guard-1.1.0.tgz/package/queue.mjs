#!/usr/bin/env node
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
import {createRequire} from 'node:module';
import {randomUUID} from 'node:crypto';
import {verify,scanPaths} from './index.mjs';
import {configKeys,validatePublication} from './publication.mjs';

const repository='omegathesecond/omevision-landing-page';
function run(command,args,{capture=false,input,cwd=process.cwd()}={}){
 const result=spawnSync(command,args,{cwd,input,encoding:'utf8',stdio:capture||input?['pipe','pipe','pipe']:'inherit',maxBuffer:64*1024*1024});
 if(result.error)throw result.error;
 if(result.status!==0)throw new Error(command+' failed'+(capture?': '+result.stderr.slice(-800):''));
 return result.stdout?.trim();
}
const args=process.argv.slice(2),options={};
try{
 for(let i=0;i<args.length;i+=2){if(!['--kind','--name','--path','--config','--branch'].includes(args[i])||!args[i+1])throw new Error('Invalid CI release option');options[args[i].slice(2)]=args[i+1];}
 if(!['pages','worker'].includes(options.kind))throw new Error('Choose pages or worker');
 await verify({phase:'source'});
 const work=await fs.mkdtemp(path.join(os.tmpdir(),'omevision-ci-release-')),payload=path.join(work,'payload');await fs.mkdir(payload);
 const meta={version:1,kind:options.kind,name:options.name,branch:options.branch||'main',source:{commit:run('git',['rev-parse','HEAD'],{capture:true})},config:{}};
 if(options.kind==='pages'){
  if(!options.path||!options.name)throw new Error('Pages release needs --path and --name');
  await scanPaths(process.cwd(),[options.path]);await fs.cp(path.resolve(options.path),path.join(payload,'site'),{recursive:true});
 }else{
  const configPath=path.resolve(options.config||'wrangler.jsonc');
  const require=createRequire(path.join(process.cwd(),'package.json'));
  const raw=require('wrangler').experimental_readRawConfig({config:configPath}).rawConfig;
  if(raw.env&&Object.keys(raw.env).length)throw new Error('Select a standalone deployment configuration; implicit environment merging is prohibited');
  meta.name=options.name||raw.name;
  for(const key of configKeys)if(raw[key]!==undefined)meta.config[key]=raw[key];
  if(raw.main){
   const compiled=path.join(work,'compiled');
   run(path.join(process.cwd(),'node_modules/.bin/wrangler'),['deploy','--dry-run','--config',configPath,'--outdir',compiled]);
   const entry=path.basename(raw.main).replace(/\.(ts|tsx|jsx|mjs|cjs)$/,'.js');
   await fs.stat(path.join(compiled,entry));await scanPaths(compiled,['.']);
   await fs.cp(compiled,path.join(payload,'worker'),{recursive:true});meta.config.main='worker/'+entry;
  }
  if(raw.assets){
   const assets=path.resolve(path.dirname(configPath),raw.assets.directory);await scanPaths(assets,['.']);
   await fs.cp(assets,path.join(payload,'site'),{recursive:true});meta.config.assets={...raw.assets,directory:'site'};
  }
 }
 await fs.writeFile(path.join(payload,'release.json'),JSON.stringify(meta));await validatePublication(payload);
 const id=randomUUID(),archive=path.join(work,'release.tar.gz'),object='gs://hiyebo_cloudbuild/ci-releases/'+id+'/release.tar.gz';
 run('tar',['-czf',archive,'-C',payload,'.']);
 run('gcloud',['--configuration=deployer','storage','cp',archive,object,'--project=hiyebo']);
 const signed=JSON.parse(run('gcloud',['--configuration=deployer','storage','sign-url',object,'--duration=30m','--path-style-url','--impersonate-service-account=deployer@hiyebo.iam.gserviceaccount.com','--format=json'],{capture:true}));
 const url=(Array.isArray(signed)?signed[0]:signed).signed_url;if(!url)throw new Error('Signing did not return an artifact URL');
 run('gh',['api','repos/'+repository+'/actions/workflows/guarded-cloudflare-release.yml/dispatches','--method','POST','--input','-'],{capture:true,input:JSON.stringify({ref:'main',inputs:{request_id:id,artifact_url:url}})});
 console.log('Queued guarded CI release '+id+' for '+meta.kind+'/'+meta.name);
 let found;
 for(let attempt=0;attempt<24&&!found;attempt++){
  const response=JSON.parse(run('gh',['api','repos/'+repository+'/actions/workflows/guarded-cloudflare-release.yml/runs?event=workflow_dispatch&per_page=30'],{capture:true}));
  found=response.workflow_runs.find(r=>r.display_title==='Guarded release '+id);
  if(!found)await new Promise(resolve=>setTimeout(resolve,5000));
 }
 if(!found)throw new Error('CI request was submitted but its run is not yet visible. Do not submit it again; find request '+id+' in the central workflow.');
 console.log(found.html_url);run('gh',['run','watch',String(found.id),'--repo',repository,'--exit-status']);
 console.log('Verified CI release succeeded: '+meta.kind+'/'+meta.name);
 await fs.rm(work,{recursive:true,force:true});
}catch(error){console.error(error.name+': '+error.message);process.exitCode=1;}
