import fs from 'node:fs/promises';
import path from 'node:path';
import {scanPaths,assertClean} from './index.mjs';
export const configKeys=['compatibility_date','compatibility_flags','workers_dev','preview_urls','assets','main','vars','routes','r2_buckets','kv_namespaces','services','durable_objects','queues','hyperdrive','d1_databases','ai','vectorize','observability','limits','placement'];
export async function validatePublication(directory){
 await scanPaths(directory,['.']);
 const meta=JSON.parse(await fs.readFile(path.join(directory,'release.json'),'utf8'));
 for(const key of Object.keys(meta))if(!['version','kind','name','branch','source','config'].includes(key))throw new Error('Unsupported release metadata field');
 if(meta.version!==1||!['pages','worker'].includes(meta.kind)||!/^[a-zA-Z0-9_-]{1,63}$/.test(meta.name))throw new Error('Invalid release target');
 if(meta.branch&&!/^[a-zA-Z0-9_/-]{1,100}$/.test(meta.branch))throw new Error('Invalid release branch');
 assertClean(JSON.stringify(meta),'release metadata');
 const config=meta.config||{};
 for(const key of Object.keys(config))if(!configKeys.includes(key))throw new Error('Unsupported Worker configuration field: '+key);
 for(const selected of [config.main,config.assets?.directory].filter(Boolean)){
  const absolute=path.resolve(directory,selected);
  if(!absolute.startsWith(path.resolve(directory)+path.sep))throw new Error('Worker input escapes the artifact');
  await fs.stat(absolute);
 }
 if(meta.kind==='pages')await fs.stat(path.join(directory,'site'));
 if(meta.kind==='worker'&&!config.main&&!config.assets)throw new Error('Worker needs compiled code or assets');
 return meta;
}
