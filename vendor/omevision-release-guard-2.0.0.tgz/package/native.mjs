#!/usr/bin/env node
import {spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
const providers=new Set(['cloudflare-workers-and-pages','google-cloud-build']);
function run(command,args){const r=spawnSync(command,args,{encoding:'utf8',maxBuffer:8*1024*1024});if(r.error)throw r.error;if(r.status!==0)throw new Error(`${command} failed: ${r.stderr.slice(-600)}`);return r.stdout.trim();}
export function selectNativeCheck(checks,{app,name,target,sha}){
 if(!providers.has(app))throw new Error('Choose a native Cloudflare or Google Cloud Build integration');
 return checks.filter(c=>c.head_sha===sha&&c.app?.slug===app&&c.name===name&&c.details_url?.includes(target)).sort((a,b)=>b.id-a.id)[0];
}
export async function waitForNativeRelease({repo,sha,app,name,target,request,sleep=ms=>new Promise(r=>setTimeout(r,ms)),attempts=240,log=console.log}){
 if(!providers.has(app)||!target||!name)throw new Error('A native app, check name and deployment target are required');
 let previous;
 for(let i=0;i<attempts;i++){
  const response=await request(`repos/${repo}/commits/${sha}/check-runs?per_page=100&filter=latest`);
  if(!Array.isArray(response.check_runs))throw new Error('GitHub did not return provider checks');
  const check=selectNativeCheck(response.check_runs,{app,name,target,sha});
  const state=check?`${check.status}/${check.conclusion||'pending'}`:'waiting for native build';
  if(state!==previous){log(state);previous=state;}
  if(check?.status==='completed'){
   if(check.conclusion!=='success')throw new Error(`Native release failed (${check.conclusion}): ${check.details_url}`);
   log(check.details_url);return check;
  }
  await sleep(5000);
 }
 throw new Error(`Native release was not verified for ${repo}@${sha}. Inspect its provider integration; no release was submitted.`);
}
export async function main(args=process.argv.slice(2)){
 const opts={};for(let i=0;i<args.length;i+=2){if(!['--app','--check','--target','--branch'].includes(args[i])||!args[i+1])throw new Error('Use --app, --check, --target and --branch');opts[args[i].slice(2)]=args[i+1];}
 if(!opts.branch)throw new Error('An explicit native release branch is required');
 const remote=run('git',['remote','get-url','origin']);const match=remote.match(/^(?:https:\/\/github\.com\/|git@github\.com:)([^/]+\/[^/]+?)(?:\.git)?$/);if(!match)throw new Error('Origin must identify the GitHub repository watched by the native integration');
 const sha=run('git',['rev-parse','HEAD']);const published=run('git',['ls-remote','--exit-code','origin',`refs/heads/${opts.branch}`]).split(/\s+/)[0];
 if(sha!==published)throw new Error(`Merge/push this commit to ${opts.branch} before verifying its automatic native release`);
 if(run('git',['status','--porcelain','--untracked-files=no']))throw new Error('Commit tracked source changes before verifying a native release');
 await waitForNativeRelease({repo:match[1],sha,app:opts.app,name:opts.check,target:opts.target,request:async endpoint=>JSON.parse(run('gh',['api',endpoint]))});
 console.log(`Verified native release: ${match[1]}@${sha}`);
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url))main().catch(e=>{console.error(e.message);process.exitCode=1;});
